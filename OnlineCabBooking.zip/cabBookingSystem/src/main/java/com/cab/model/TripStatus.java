package com.cab.model;

public enum TripStatus {

	CONFIRMED, CANCELED, WAITING, RUNNING, COMPLETED
}

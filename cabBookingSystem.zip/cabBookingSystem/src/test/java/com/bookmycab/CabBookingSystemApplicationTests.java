package com.bookmycab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CabBookingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}

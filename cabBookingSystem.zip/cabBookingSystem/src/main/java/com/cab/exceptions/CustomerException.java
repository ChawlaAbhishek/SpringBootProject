package com.cab.exceptions;


public class CustomerException extends UserException {
    public CustomerException() {
    }

    public CustomerException(String message) {
        super(message);
    }
}

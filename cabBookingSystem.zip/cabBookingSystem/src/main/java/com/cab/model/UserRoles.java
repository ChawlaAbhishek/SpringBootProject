package com.cab.model;

public enum UserRoles {
	
    USER,
    CUSTOMER,
    DRIVER,
    ADMIN,
    
}
